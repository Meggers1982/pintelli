"use client";

import { useState, useRef } from "react";
import styles from "./PinterestTool.module.css";

const EXAMPLES = [
  "home renovation",
  "women's wellness",
  "plant-based recipes",
  "menopause health",
  "pet care",
  "budget travel",
  "small business marketing",
];

function extractJSON(str) {
  let s = str.trim();
  try { return JSON.parse(s); } catch (_) {}
  const start = s.indexOf("{");
  if (start === -1) throw new Error("No JSON in response");
  let depth = 0, end = -1;
  for (let i = start; i < s.length; i++) {
    if (s[i] === "{") depth++;
    else if (s[i] === "}") { depth--; if (depth === 0) { end = i; break; } }
  }
  if (end === -1) throw new Error("Malformed JSON");
  return JSON.parse(s.slice(start, end + 1));
}

export default function PinterestTool() {
  const [niche, setNiche]       = useState("");
  const [loading, setLoading]   = useState(false);
  const [results, setResults]   = useState(null);
  const [error, setError]       = useState(null);
  const [pinsOpen, setPinsOpen] = useState(false);
  const inputRef                = useRef(null);

  async function research() {
    if (!niche.trim()) return;
    setLoading(true);
    setError(null);
    setResults(null);
    setPinsOpen(false);

    try {
      const res = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ niche: niche.trim() }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Request failed");
      }

      // data may come back as pre-parsed from the API route
      // or as a raw JSON string if something wrapped it
      const parsed = (data.trending_keywords)
        ? data
        : extractJSON(JSON.stringify(data));

      setResults({ ...parsed, niche: niche.trim() });

    } catch (e) {
      setError(e.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setResults(null);
    setError(null);
    setNiche("");
    setPinsOpen(false);
    setTimeout(() => inputRef.current?.focus(), 100);
  }

  const meta = results?.meta || {};

  return (
    <div className={styles.app}>

      {/* Top bar */}
      <div className={styles.bar}>
        <div className={styles.brand}>
          <div className={styles.brandDot} />
          Pinterest Intelligence
        </div>
        <div className={styles.barTag}>
          {meta.usedSerp ? "Live + AI" : "AI Analysis"}
        </div>
      </div>

      <div className={styles.main}>

        {/* Hero */}
        {!results && !loading && (
          <div className={styles.hero}>
            <div>
              <div className={styles.kicker}>Trend Research</div>
              <h1 className={styles.h1}>
                What <em>actually</em><br />performs on<br />Pinterest
              </h1>
              <p className={styles.sub}>
                Enter your niche to get trending keywords, content angles, seasonal peaks, and gaps — synthesized by AI.
              </p>
            </div>
            <div className={styles.ghost}>P</div>
          </div>
        )}

        {/* Search */}
        {!results && !loading && (
          <>
            <div className={styles.searchWrap}>
              <div className={styles.searchBox}>
                <input
                  ref={inputRef}
                  type="text"
                  placeholder="Enter a niche — home renovation, menopause health..."
                  value={niche}
                  onChange={e => setNiche(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && research()}
                />
                <div className={styles.sdiv} />
                <button
                  className={styles.sbtn}
                  onClick={research}
                  disabled={!niche.trim()}
                >
                  <span className={styles.lbl}>Research</span>
                  <span>&#8594;</span>
                </button>
              </div>
            </div>

            <div className={styles.chipsLabel}>Quick starts</div>
            <div className={styles.chips}>
              {EXAMPLES.map(ex => (
                <button
                  key={ex}
                  className={styles.chip}
                  onClick={() => setNiche(ex)}
                >
                  {ex}
                </button>
              ))}
            </div>
          </>
        )}

        {/* Loading */}
        {loading && (
          <div className={styles.loading}>
            <div className={styles.spinner} />
            <div className={styles.loadingLabel}>
              Researching Pinterest trends for &ldquo;{niche}&rdquo;&hellip;
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <>
            <div className={styles.errBox}>&#9888; {error}</div>
            <button className={styles.backBtn} onClick={reset}>
              &#8592; Try again
            </button>
          </>
        )}

        {/* Results */}
        {results && (
          <div className={styles.dossier}>

            <div className={styles.dhead}>
              <div>
                <div className={styles.dlbl}>Trend Report</div>
                <div className={styles.dniche}>{results.niche}</div>
              </div>
              {meta.usedSerp && (
                <div className={styles.dmeta}>
                  <strong>{meta.pinsCount} live pins</strong> scraped<br />
                  + autocomplete data<br />
                  + AI synthesis
                </div>
              )}
            </div>

            {/* Keywords */}
            <div className={styles.sec}>
              <div className={styles.srule} />
              <div className={styles.slbl}>Trending Keywords</div>
              <div className={styles.kws}>
                {(results.trending_keywords || []).map((kw, i) => (
                  <span key={i} className={styles.kw}>{kw}</span>
                ))}
                {(meta.acTerms || [])
                  .filter(t => t && !(results.trending_keywords || []).includes(t))
                  .map((t, i) => (
                    <span key={"ac" + i} className={styles.kwAc}>{t}</span>
                  ))}
              </div>
              {meta.usedSerp && meta.acTerms?.length > 0 && (
                <div className={styles.legend}>
                  <div className={styles.legItem}>
                    <div className={styles.legSw} style={{ background: "#EDE9E1" }} />
                    From live pins
                  </div>
                  <div className={styles.legItem}>
                    <div className={styles.legSw} style={{ background: "#EAF3EE" }} />
                    Real autocomplete searches
                  </div>
                </div>
              )}
            </div>

            {/* Two-column: angles + formats/gaps */}
            <div className={styles.twoCol}>
              <div className={styles.sec}>
                <div className={styles.srule} />
                <div className={styles.slbl}>Content Angles</div>
                {(results.content_angles || []).map((a, i) => (
                  <div key={i} className={styles.angle}>
                    <div className={styles.anum}>0{i + 1}</div>
                    <div>
                      <div className={styles.atitle}>{a.angle}</div>
                      <div className={styles.awhy}>{a.why}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div>
                <div className={styles.sec}>
                  <div className={styles.srule} />
                  <div className={styles.slbl}>Top Pin Formats</div>
                  {(results.top_formats || []).map((f, i) => (
                    <div key={i} className={styles.fmt}>
                      <div className={styles.fbullet} />
                      {f}
                    </div>
                  ))}
                </div>

                <div className={styles.sec}>
                  <div className={styles.srule} />
                  <div className={styles.slbl}>Content Gaps</div>
                  {(results.content_gaps || []).map((g, i) => (
                    <div key={i} className={styles.gapItem}>
                      <span className={styles.garrow}>&#8594;</span>
                      {g}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Seasonal */}
            <div className={styles.sec}>
              <div className={styles.srule} />
              <div className={styles.slbl}>Seasonal Peaks</div>
              <div className={styles.seasonal}>
                {(results.seasonal_peaks || []).map((s, i) => (
                  <div key={i} className={styles.scell}>
                    <div className={styles.smo}>{s.month}</div>
                    <div className={styles.stopic}>{s.topic}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Takeaway */}
            {results.summary && (
              <div className={styles.sec}>
                <div className={styles.srule} />
                <div className={styles.slbl}>Strategic Takeaway</div>
                <div className={styles.take}>
                  <div className={styles.tlbl}>Synthesis</div>
                  <div
                    className={styles.ttext}
                    dangerouslySetInnerHTML={{
                      __html: results.summary.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>"),
                    }}
                  />
                </div>
              </div>
            )}

            {/* Raw pins (SerpAPI only) */}
            {meta.rawPins?.length > 0 && (
              <>
                <button
                  className={styles.rawBtn}
                  onClick={() => setPinsOpen(o => !o)}
                >
                  {pinsOpen ? "Hide" : "View"} raw scraped pins ({meta.rawPins.length})
                </button>
                {pinsOpen && (
                  <div className={styles.rawList}>
                    {meta.rawPins.map((p, i) => (
                      <div key={i} className={styles.rawPin}>
                        <div className={styles.rawPinTitle}>{p.title || "(no title)"}</div>
                        {p.description && (
                          <div>{p.description.slice(0, 130)}{p.description.length > 130 ? "..." : ""}</div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            <button className={styles.backBtn} onClick={reset}>
              &#8592; Research another niche
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
