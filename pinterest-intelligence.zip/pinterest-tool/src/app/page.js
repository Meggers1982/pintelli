import PinterestTool from "../components/PinterestTool";

export default function Home() {
  return <PinterestTool />;
}
