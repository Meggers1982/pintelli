export async function POST(request) {
  try {
    const { niche } = await request.json();

    if (!niche || !niche.trim()) {
      return Response.json({ error: "Niche is required" }, { status: 400 });
    }

    const ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY;
    const SERP_KEY = process.env.SERPAPI_KEY;

    if (!ANTHROPIC_KEY) {
      return Response.json({ error: "ANTHROPIC_API_KEY not configured" }, { status: 500 });
    }

    let allPins = [];
    let acTerms = [];
    const usedSerp = !!SERP_KEY;

    // ── SerpAPI: fetch live Pinterest pins + autocomplete ──
    if (SERP_KEY) {
      try {
        const [p1, p2, p3, ac] = await Promise.all([
          fetchPins(niche, SERP_KEY),
          fetchPins(niche + " ideas", SERP_KEY),
          fetchPins(niche + " tips", SERP_KEY),
          fetchAutocomplete(niche, SERP_KEY),
        ]);
        allPins = [...p1, ...p2, ...p3];
        acTerms = ac;
      } catch (serpErr) {
        console.error("SerpAPI error:", serpErr.message);
        // Continue without live data — degrade gracefully
      }
    }

    // ── Build context strings ──
    const pinsText = allPins.length
      ? "\n\nLIVE PINTEREST PINS (" + allPins.length + " pins scraped):\n" +
        allPins.map((p, i) => "[" + (i + 1) + "] " + (p.title || "(no title)") + " | " + (p.description || "").slice(0, 100)).join("\n")
      : "";

    const acText = acTerms.length
      ? "\n\nAUTOCOMPLETE TERMS (real Pinterest searches):\n" + acTerms.map(t => "- " + t).join("\n")
      : "";

    // ── Claude: analyze and return structured JSON ──
    const systemPrompt = [
      "You are a Pinterest SEO and content strategy expert.",
      "Return ONLY a raw JSON object. No explanation, no markdown, no text before or after.",
      "Your response must start with { and end with }.",
      "JSON structure:",
      "{",
      "  \"trending_keywords\": [10 specific keyword phrases people search on Pinterest for this niche],",
      "  \"autocomplete_terms\": [5 high-value autocomplete-style search terms],",
      "  \"content_angles\": [",
      "    {\"angle\": \"Title\", \"why\": \"Why this performs well on Pinterest — be specific\"},",
      "    {\"angle\": \"Title\", \"why\": \"Reason\"},",
      "    {\"angle\": \"Title\", \"why\": \"Reason\"},",
      "    {\"angle\": \"Title\", \"why\": \"Reason\"}",
      "  ],",
      "  \"seasonal_peaks\": [",
      "    {\"month\": \"Jan\", \"topic\": \"Specific seasonal content idea\"},",
      "    {\"month\": \"Mar\", \"topic\": \"idea\"},",
      "    {\"month\": \"Jun\", \"topic\": \"idea\"},",
      "    {\"month\": \"Sep\", \"topic\": \"idea\"},",
      "    {\"month\": \"Nov\", \"topic\": \"idea\"}",
      "  ],",
      "  \"top_formats\": [5 pin formats that perform best in this niche],",
      "  \"content_gaps\": [4 underserved angles competitors are missing],",
      "  \"summary\": \"2-3 sentences: dominant pattern in this niche + the single biggest content opportunity right now.\"",
      "}",
      "When live pin data is provided, derive keywords and angles from real pin titles and descriptions.",
      "Be specific — name real keyword phrases, concrete content angles, actual seasonal moments."
    ].join("\n");

    const userMsg = "Analyze Pinterest trends for: \"" + niche.trim() + "\"" + pinsText + acText + "\n\nReturn the JSON.";

    const claudeRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-5",
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{ role: "user", content: userMsg }],
      }),
    });

    const claudeData = await claudeRes.json();

    if (!claudeRes.ok) {
      return Response.json(
        { error: claudeData.error?.message || "Claude API error" },
        { status: claudeRes.status }
      );
    }

    const rawText = (claudeData.content || [])
      .filter(b => b.type === "text")
      .map(b => b.text)
      .join(" ")
      .trim();

    const parsed = extractJSON(rawText);

    return Response.json({
      ...parsed,
      meta: {
        niche: niche.trim(),
        usedSerp,
        pinsCount: allPins.length,
        acTerms,
        rawPins: allPins,
      },
    });

  } catch (err) {
    console.error("Research API error:", err);
    return Response.json({ error: err.message || "Internal server error" }, { status: 500 });
  }
}

// ── Helpers ──

async function fetchPins(query, key) {
  const url = "https://serpapi.com/search.json?engine=pinterest&q=" +
    encodeURIComponent(query) + "&api_key=" + encodeURIComponent(key);
  const res = await fetch(url);
  if (!res.ok) return [];
  const data = await res.json();
  return (data.pins || []).slice(0, 15).map(p => ({
    title: p.title || "",
    description: p.description || "",
  }));
}

async function fetchAutocomplete(query, key) {
  const url = "https://serpapi.com/search.json?engine=google_autocomplete&q=" +
    encodeURIComponent("pinterest " + query) + "&api_key=" + encodeURIComponent(key);
  const res = await fetch(url);
  if (!res.ok) return [];
  const data = await res.json();
  return (data.suggestions || [])
    .map(s => (s.value || "").replace(/^pinterest\s*/i, "").trim())
    .filter(Boolean)
    .slice(0, 10);
}

function extractJSON(str) {
  let s = str.trim();
  try { return JSON.parse(s); } catch (_) {}
  const start = s.indexOf("{");
  if (start === -1) throw new Error("No JSON found in response: " + s.slice(0, 100));
  let depth = 0, end = -1;
  for (let i = start; i < s.length; i++) {
    if (s[i] === "{") depth++;
    else if (s[i] === "}") {
      depth--;
      if (depth === 0) { end = i; break; }
    }
  }
  if (end === -1) throw new Error("Unterminated JSON in response");
  return JSON.parse(s.slice(start, end + 1));
}
