# Pinterest Intelligence

Find what actually performs on Pinterest — trending keywords, content angles, seasonal peaks, and gaps, synthesized by AI.

## Stack

- **Next.js 14** (App Router)
- **Anthropic Claude** for analysis
- **SerpAPI** (optional) for live Pinterest pin data + autocomplete

---

## Setup

### 1. Clone and install

```bash
git clone <your-repo>
cd pinterest-intelligence
npm install
```

### 2. Add environment variables

```bash
cp .env.local.example .env.local
```

Edit `.env.local`:

```
ANTHROPIC_API_KEY=your_anthropic_key_here
SERPAPI_KEY=your_serpapi_key_here   # optional
```

- **Anthropic key**: https://console.anthropic.com
- **SerpAPI key**: https://serpapi.com (100 free searches/month)

Without SerpAPI, the tool uses Claude's training knowledge of Pinterest trends — still solid for most niches.

### 3. Run locally

```bash
npm run dev
```

Open http://localhost:3000

---

## Deploy to Vercel

### Option A — Vercel CLI

```bash
npm i -g vercel
vercel
```

### Option B — GitHub + Vercel dashboard

1. Push to GitHub
2. Go to https://vercel.com/new and import the repo
3. Add environment variables in the Vercel dashboard:
   - `ANTHROPIC_API_KEY`
   - `SERPAPI_KEY` (optional)
4. Deploy

---

## How it works

```
Browser → POST /api/research { niche }
  └─ API Route (server-side):
       1. Fetch live Pinterest pins via SerpAPI (if key present)
       2. Fetch Google autocomplete for "pinterest [niche]"
       3. Send pin data + niche to Claude for analysis
       4. Return structured JSON
Browser ← { trending_keywords, content_angles, seasonal_peaks, ... }
```

All API keys stay server-side — never exposed to the browser.

---

## Project structure

```
src/
  app/
    api/research/route.js   ← server-side API handler
    layout.js
    page.js
    globals.css
  components/
    PinterestTool.js        ← main React component
    PinterestTool.module.css
```
